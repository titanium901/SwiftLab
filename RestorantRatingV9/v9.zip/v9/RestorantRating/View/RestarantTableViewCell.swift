//
//  RestarantTableViewCell.swift
//  RestorantRating
//
//  Created by Yury Popov on 02/07/2019.
//  Copyright © 2019 Yury Popov. All rights reserved.
//

import UIKit

class RestarantTableViewCell: UITableViewCell {
    
    
    @IBOutlet var imageName: UIImageView!
    @IBOutlet var name: UILabel!
    @IBOutlet var staff: UILabel!
    
}
